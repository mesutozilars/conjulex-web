import { useState, useEffect } from 'react';
import axios from 'axios';
import SearchBar from './components/SearchBar';
import WordCard from './components/WordCard';
import ConjugationTable from './components/ConjugationTable';
import './App.css';

// API 엔드포인트 - 개발/배포 환경에 따라 자동 설정
const API_BASE_URL = typeof window !== 'undefined' && window.location.hostname === 'localhost'
  ? 'http://localhost:3000/api/trpc'
  : `${window.location.origin}/api/trpc`;

export default function App() {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedLanguage, setSelectedLanguage] = useState('de');
  const [selectedType, setSelectedType] = useState('noun');
  const [wordData, setWordData] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [recentWords, setRecentWords] = useState([]);

  // 최근 검색 단어 로드
  useEffect(() => {
    const saved = localStorage.getItem('recentWords');
    if (saved) {
      setRecentWords(JSON.parse(saved));
    }
  }, []);

  // 최근 검색 단어 저장
  const saveRecentWord = (word) => {
    const updated = [word, ...recentWords.filter(w => w !== word)].slice(0, 10);
    setRecentWords(updated);
    localStorage.setItem('recentWords', JSON.stringify(updated));
  };

  const handleSearch = async (e) => {
    e.preventDefault();
    if (!searchQuery.trim()) return;

    setLoading(true);
    setError('');
    setWordData(null);

    try {
      const input = {
        word: searchQuery,
        lang: selectedLanguage,
        type: selectedType,
      };

      const response = await axios.get(
        `${API_BASE_URL}/conjugation.generate?input=${encodeURIComponent(JSON.stringify({ '0': { json: input } }))}&batch=1`
      );

      if (response.data && response.data[0]?.result?.data?.json) {
        const data = response.data[0].result.data.json;
        setWordData(data);
        saveRecentWord(searchQuery);
      } else {
        setError('단어를 찾을 수 없습니다.');
      }
    } catch (err) {
      setError(err.message || '오류가 발생했습니다.');
      console.error('Search error:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleQuickSearch = (word) => {
    setSearchQuery(word);
    // 검색 실행
    setTimeout(() => {
      const form = document.querySelector('form');
      if (form) form.dispatchEvent(new Event('submit', { bubbles: true }));
    }, 0);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-900 via-blue-800 to-blue-900">
      <header className="bg-blue-950 text-white shadow-lg">
        <div className="max-w-6xl mx-auto px-4 py-6">
          <h1 className="text-4xl font-bold mb-2">ConjuLex</h1>
          <p className="text-blue-200">독일어 · 프랑스어 · 스페인어 변형표 사전</p>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-4 py-8">
        {/* 검색 섹션 */}
        <SearchBar
          searchQuery={searchQuery}
          setSearchQuery={setSearchQuery}
          selectedLanguage={selectedLanguage}
          setSelectedLanguage={setSelectedLanguage}
          selectedType={selectedType}
          setSelectedType={setSelectedType}
          onSearch={handleSearch}
          loading={loading}
        />

        {/* 에러 메시지 */}
        {error && (
          <div className="mt-4 p-4 bg-red-500 text-white rounded-lg">
            {error}
          </div>
        )}

        {/* 결과 표시 */}
        {wordData && (
          <div className="mt-8">
            <WordCard word={wordData} />
            <ConjugationTable word={wordData} />
          </div>
        )}

        {/* 최근 검색 */}
        {recentWords.length > 0 && !wordData && (
          <div className="mt-8">
            <h2 className="text-2xl font-bold text-white mb-4">최근 검색</h2>
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-3">
              {recentWords.map((word) => (
                <button
                  key={word}
                  onClick={() => handleQuickSearch(word)}
                  className="bg-blue-700 hover:bg-blue-600 text-white px-4 py-2 rounded-lg transition"
                >
                  {word}
                </button>
              ))}
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
