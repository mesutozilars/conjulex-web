export default function WordCard({ word }) {
  const getLanguageName = (lang) => {
    const names = { de: '독일어', fr: '프랑스어', es: '스페인어' };
    return names[lang] || lang;
  };

  const getTypeName = (type) => {
    const names = { noun: '명사', verb: '동사', adj: '형용사' };
    return names[type] || type;
  };

  return (
    <div className="bg-white rounded-lg shadow-lg p-6 mb-6">
      <div className="flex items-start justify-between mb-4">
        <div>
          <h2 className="text-4xl font-bold text-gray-900">{word.word}</h2>
          <p className="text-gray-600 mt-1">
            {getLanguageName(word.lang)} · {getTypeName(word.type)}
          </p>
        </div>
        <div className="text-right">
          {word.article && (
            <p className="text-2xl font-semibold text-blue-600">{word.article}</p>
          )}
          {word.gender && (
            <p className="text-sm text-gray-600 mt-1">
              성: <span className="font-semibold">{word.gender}</span>
            </p>
          )}
        </div>
      </div>

      {/* 의미 */}
      {word.meaning && (
        <div className="mb-4 p-3 bg-blue-50 rounded-lg">
          <p className="text-gray-700">
            <span className="font-semibold text-gray-900">의미:</span> {word.meaning}
          </p>
        </div>
      )}

      {/* 복수형 */}
      {word.plural && (
        <div className="grid grid-cols-2 gap-4">
          <div className="p-3 bg-gray-50 rounded-lg">
            <p className="text-sm text-gray-600">단수</p>
            <p className="text-lg font-semibold text-gray-900">{word.word}</p>
          </div>
          <div className="p-3 bg-gray-50 rounded-lg">
            <p className="text-sm text-gray-600">복수</p>
            <p className="text-lg font-semibold text-gray-900">{word.plural}</p>
          </div>
        </div>
      )}

      {/* 보조동사 (동사인 경우) */}
      {word.auxiliary && (
        <div className="mt-4 p-3 bg-green-50 rounded-lg">
          <p className="text-gray-700">
            <span className="font-semibold text-gray-900">보조동사:</span> {word.auxiliary}
          </p>
        </div>
      )}
    </div>
  );
}
