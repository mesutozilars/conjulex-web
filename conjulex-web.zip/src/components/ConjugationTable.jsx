export default function ConjugationTable({ word }) {
  // 명사 변형표
  if (word.declension) {
    return (
      <div className="space-y-6">
        {/* 단수 */}
        <div className="bg-white rounded-lg shadow-lg overflow-hidden">
          <div className="bg-blue-600 text-white px-6 py-3">
            <h3 className="text-lg font-bold">단수 (Singular)</h3>
          </div>
          <table className="w-full">
            <thead className="bg-gray-100">
              <tr>
                <th className="px-6 py-3 text-left font-semibold text-gray-900">격</th>
                <th className="px-6 py-3 text-left font-semibold text-gray-900">형태</th>
              </tr>
            </thead>
            <tbody>
              {word.declension.singular && Object.entries(word.declension.singular).map(([case_, form]) => (
                <tr key={case_} className="border-t hover:bg-gray-50">
                  <td className="px-6 py-3 font-semibold text-gray-900 capitalize">{getCaseName(case_)}</td>
                  <td className="px-6 py-3 text-gray-700">{form}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* 복수 */}
        {word.declension.plural && (
          <div className="bg-white rounded-lg shadow-lg overflow-hidden">
            <div className="bg-blue-600 text-white px-6 py-3">
              <h3 className="text-lg font-bold">복수 (Plural)</h3>
            </div>
            <table className="w-full">
              <thead className="bg-gray-100">
                <tr>
                  <th className="px-6 py-3 text-left font-semibold text-gray-900">격</th>
                  <th className="px-6 py-3 text-left font-semibold text-gray-900">형태</th>
                </tr>
              </thead>
              <tbody>
                {Object.entries(word.declension.plural).map(([case_, form]) => (
                  <tr key={case_} className="border-t hover:bg-gray-50">
                    <td className="px-6 py-3 font-semibold text-gray-900 capitalize">{getCaseName(case_)}</td>
                    <td className="px-6 py-3 text-gray-700">{form}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    );
  }

  // 동사 변형표
  if (word.conjugation) {
    return (
      <div className="space-y-6">
        {Object.entries(word.conjugation).map(([tense, forms]) => (
          <div key={tense} className="bg-white rounded-lg shadow-lg overflow-hidden">
            <div className="bg-blue-600 text-white px-6 py-3">
              <h3 className="text-lg font-bold">{getTenseName(tense)}</h3>
            </div>
            <table className="w-full">
              <thead className="bg-gray-100">
                <tr>
                  <th className="px-6 py-3 text-left font-semibold text-gray-900">인칭</th>
                  <th className="px-6 py-3 text-left font-semibold text-gray-900">형태</th>
                </tr>
              </thead>
              <tbody>
                {typeof forms === 'object' && Object.entries(forms).map(([person, form]) => (
                  <tr key={person} className="border-t hover:bg-gray-50">
                    <td className="px-6 py-3 font-semibold text-gray-900 capitalize">{getPersonName(person)}</td>
                    <td className="px-6 py-3 text-gray-700">{form}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ))}

        {/* 과거분사 */}
        {word.partizip && (
          <div className="bg-white rounded-lg shadow-lg overflow-hidden">
            <div className="bg-blue-600 text-white px-6 py-3">
              <h3 className="text-lg font-bold">과거분사 (Partizip)</h3>
            </div>
            <div className="px-6 py-4">
              <p className="text-lg font-semibold text-gray-900">{word.partizip}</p>
            </div>
          </div>
        )}
      </div>
    );
  }

  return null;
}

function getCaseName(case_) {
  const names = {
    nom: '주격 (Nominativ)',
    acc: '목적격 (Akkusativ)',
    dat: '여격 (Dativ)',
    gen: '소유격 (Genitiv)',
  };
  return names[case_] || case_;
}

function getTenseName(tense) {
  const names = {
    praesens: '현재 (Präsens)',
    praeteritum: '과거 (Präteritum)',
    perfekt: '현재완료 (Perfekt)',
    plusquamperfekt: '과거완료 (Plusquamperfekt)',
    futur1: '미래 (Futur I)',
    futur2: '미래완료 (Futur II)',
    konjunktiv1: '접속법 I (Konjunktiv I)',
    konjunktiv2: '접속법 II (Konjunktiv II)',
  };
  return names[tense] || tense;
}

function getPersonName(person) {
  const names = {
    ich: 'ich (나)',
    du: 'du (너)',
    er: 'er/sie/es (그/그녀/그것)',
    wir: 'wir (우리)',
    ihr: 'ihr (너희)',
    sie: 'sie (그들)',
    je: 'je (나)',
    tu: 'tu (너)',
    il: 'il/elle (그/그녀)',
    nous: 'nous (우리)',
    vous: 'vous (너희)',
    yo: 'yo (나)',
    eres: 'eres (너)',
    el: 'él/ella (그/그녀)',
    nosotros: 'nosotros (우리)',
    vosotros: 'vosotros (너희)',
    ellos: 'ellos (그들)',
  };
  return names[person] || person;
}
