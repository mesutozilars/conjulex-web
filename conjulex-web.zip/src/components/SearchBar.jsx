export default function SearchBar({
  searchQuery,
  setSearchQuery,
  selectedLanguage,
  setSelectedLanguage,
  selectedType,
  setSelectedType,
  onSearch,
  loading,
}) {
  return (
    <form onSubmit={onSearch} className="bg-white rounded-lg shadow-lg p-6">
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-4">
        {/* 언어 선택 */}
        <div>
          <label className="block text-sm font-semibold text-gray-700 mb-2">
            언어
          </label>
          <select
            value={selectedLanguage}
            onChange={(e) => setSelectedLanguage(e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
          >
            <option value="de">🇩🇪 독일어</option>
            <option value="fr">🇫🇷 프랑스어</option>
            <option value="es">🇪🇸 스페인어</option>
          </select>
        </div>

        {/* 단어 타입 선택 */}
        <div>
          <label className="block text-sm font-semibold text-gray-700 mb-2">
            타입
          </label>
          <select
            value={selectedType}
            onChange={(e) => setSelectedType(e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
          >
            <option value="noun">명사</option>
            <option value="verb">동사</option>
            <option value="adj">형용사</option>
          </select>
        </div>

        {/* 검색 입력 */}
        <div className="md:col-span-2">
          <label className="block text-sm font-semibold text-gray-700 mb-2">
            단어 검색
          </label>
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="예: sein, maison, ser"
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>
      </div>

      {/* 검색 버튼 */}
      <button
        type="submit"
        disabled={loading}
        className="w-full bg-blue-600 hover:bg-blue-700 disabled:bg-gray-400 text-white font-semibold py-2 px-4 rounded-lg transition"
      >
        {loading ? '검색 중...' : '검색'}
      </button>
    </form>
  );
}
